export class Task {

    task_name:any;
    desc:any;
    status:Boolean;
}
