import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otpand-email',
  templateUrl: './otpand-email.component.html',
  styleUrls: ['./otpand-email.component.css']
})
export class OTPandEmailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
