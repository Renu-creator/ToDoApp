import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-task',
  templateUrl: './register-task.component.html',
  styleUrls: ['./register-task.component.css']
})
export class RegisterTaskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
