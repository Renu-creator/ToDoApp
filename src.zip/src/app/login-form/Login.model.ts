export class LoginModel
{
    fname:any;
    pass:any;
    email:any;
    otp:any;
}