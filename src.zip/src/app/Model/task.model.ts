
export class task
{
   taskid:any;
    taskname:any;
    desc:any;
    taskstatus:any;
    email:any;
}