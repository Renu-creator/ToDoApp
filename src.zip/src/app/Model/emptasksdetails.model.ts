export class Emptasks
{
    empid:any;
    empfname:any;
    emplname:any;
    taskname:any;
    desc:any;
    taskstatus:any;
    empstatus:any;
}