export class OTPmodel
{
    email:any;
    otp:any;
}