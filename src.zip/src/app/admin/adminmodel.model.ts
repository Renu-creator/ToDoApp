export class adminloginmodel
{
    fname:any;
    pass:any;
}